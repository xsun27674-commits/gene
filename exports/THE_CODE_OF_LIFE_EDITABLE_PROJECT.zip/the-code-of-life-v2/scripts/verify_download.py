"""Verify bytes received from an explicitly supplied HTTPS download URL."""
import argparse, hashlib, json, urllib.request
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('file');p.add_argument('url');p.add_argument('proof');a=p.parse_args()
f=Path(a.file);expected=hashlib.sha256(f.read_bytes()).hexdigest()
req=urllib.request.Request(a.url,headers={'User-Agent':'Codex-delivery-verification'})
h=hashlib.sha256();size=0
with urllib.request.urlopen(req,timeout=120) as r:
 status=r.status
 assert status==200,status
 while True:
  b=r.read(1024*1024)
  if not b:break
  size+=len(b);h.update(b)
assert size==f.stat().st_size,(size,f.stat().st_size)
assert h.hexdigest()==expected,(h.hexdigest(),expected)
proof={'verified':True,'url':a.url,'http_status':status,'downloaded_bytes':size,'sha256':expected}
Path(a.proof).write_text(json.dumps(proof,indent=2));print(json.dumps(proof),flush=True)
