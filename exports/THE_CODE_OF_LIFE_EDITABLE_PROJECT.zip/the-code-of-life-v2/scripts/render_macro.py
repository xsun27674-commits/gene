"""Cinematic virtual camera moves over generated photographic texture assets.
Bird shot is a transparent foreground/background glide composite. No claim of
live wildlife footage or AI-generated continuous animal video.
"""
from pathlib import Path
import json,math,os
from PIL import Image
R=Path(__file__).resolve().parents[1];P=json.loads((R/'analysis/plan.json').read_text())
imgs={n:Image.open(R/'assets'/(n+'.png')).convert('RGB') for n in ['flower','corn','butterfly','iris','cat','leaf','forest','forest_background']}
bird=Image.open(R/'assets/bird_cutout.png').convert('RGBA')
def camera(im,zoom,center,size=(1920,1080)):
 w,h=im.size;cw=w/zoom;ch=cw*9/16
 cx=max(cw/2,min(w-cw/2,center[0]*w));cy=max(ch/2,min(h-ch/2,center[1]*h))
 return im.transform(size,Image.Transform.EXTENT,(cx-cw/2,cy-ch/2,cx+cw/2,cy+ch/2),Image.Resampling.BICUBIC)
def smooth(t):return t*t*(3-2*t)
spec={10:('flower',1.03,1.17,(.49,.49),(.57,.56)),11:('corn',1.18,1.09,(.44,.44),(.57,.56)),12:('butterfly',1.30,1.04,(.61,.49),(.5,.5)),13:('iris',1.04,1.28,(.53,.5),(.55,.53)),14:('cat',1.72,1.03,(.47,.4),(.5,.5)),15:('leaf',1.24,1.01,(.48,.5),(.5,.5))}
preview=os.environ.get('COL_MACRO_PREVIEW','0')=='1'
for sh in P['shots']:
 idx=sh['shot']
 if not 10<=idx<=17:continue
 if os.environ.get('COL_MACRO_SHOT') and idx!=int(os.environ['COL_MACRO_SHOT']):continue
 out=R/('previews' if preview else 'frames')/('S%02d'%idx);out.mkdir(parents=True,exist_ok=True)
 frameids=range(sh['first_frame']-9,sh['last_frame']+10,3 if preview else 1)
 for f in frameids:
  dst=out/('frame_%04d.png'%f)
  if dst.exists():continue
  t=max(0,min(1,(f-sh['first_frame'])/max(1,sh['frames']-1)));u=smooth(t)
  if idx in spec:
   n,z0,z1,c0,c1=spec[idx];im=camera(imgs[n],z0+(z1-z0)*u,(c0[0]+(c1[0]-c0[0])*u,c0[1]+(c1[1]-c0[1])*u))
  elif idx==16:
   im=camera(imgs['forest_background'],1.1,(.53-.08*t,.5)).convert('RGBA')
   w=round(840+70*t);b=bird.resize((w,round(w*bird.height/bird.width)),Image.Resampling.LANCZOS)
   b=b.rotate(-2+4*t,Image.Resampling.BICUBIC,expand=True)
   x=round(160+550*t);y=round(190-35*math.sin(math.pi*t))
   im.alpha_composite(b,(x,y));im=im.convert('RGB')
  else:
   count=sh['frames'];relative=f-sh['first_frame'];cuts=[0,17,34,52,70,count]
   names=['flower','butterfly','forest','cat','iris'];j=max(0,min(4,next((k for k in range(5) if relative<cuts[k+1]),4)))
   v=max(0,min(1,(relative-cuts[j])/max(1,cuts[j+1]-cuts[j]-1)))
   im=camera(imgs[names[j]],1.06+.10*v,(.5,.5))
  if preview:im=im.resize((960,540),Image.Resampling.LANCZOS)
  im.save(dst,compress_level=2)
 print('MACRO_COMPLETE S%02d'%idx,flush=True)
