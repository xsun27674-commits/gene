import bpy,json
from pathlib import Path
R=Path(__file__).resolve().parents[1];s=bpy.context.scene;rows=[]
for f in range(271,302):
 s.frame_set(f);bpy.context.view_layer.update();c=s.camera
 rows.append({'frame':f,'seconds':(f-1)/30,'position':list(c.matrix_world.translation),'euler':list(c.rotation_euler),'lens_mm':c.data.lens,'sensor_width_mm':c.data.sensor_width,'fstop':c.data.dof.aperture_fstop})
reference=json.loads((R/'analysis/continuity_camera.json').read_text())
last=rows[-1]
assert max(abs(a-b) for a,b in zip(last['position'],reference['camera_301']))<1e-6
assert max(abs(a-b) for a,b in zip(last['euler'],reference['actual_rotation_301']))<1e-6
assert abs(last['lens_mm']-reference['actual_lens_301'])<1e-6
(R/'analysis/source_camera_last30.json').write_text(json.dumps({'first_new_camera_matches_source_extrapolation':True,'frames':rows},indent=2))
print('Original last-30-frame camera curves audited; first new camera inherits source exactly.')
