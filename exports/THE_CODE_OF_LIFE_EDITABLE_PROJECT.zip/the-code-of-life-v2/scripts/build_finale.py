import bpy,math,random,json
from pathlib import Path
from mathutils import Vector,Quaternion
R=Path(__file__).resolve().parents[1];s=bpy.context.scene;s.frame_set(300)
plan=json.loads((R/'analysis/plan.json').read_text());sh={x['shot']:x for x in plan['shots']}
def key(o,path,vals):
 for f,v in vals:setattr(o,path,v);o.keyframe_insert(path,frame=f)
def nodekey(socket,vals):
 for f,v in vals:socket.default_value=v;socket.keyframe_insert('default_value',frame=f)
for ob in s.objects:
 if ob.name.startswith('Assembly microstructure') or ob.name.startswith('The beginning'):ob.hide_render=True
for m in bpy.data.materials:
 if not m.use_nodes:continue
 m.node_tree.animation_data_clear()
 for node in m.node_tree.nodes:
  if node.bl_idname=='ShaderNodeMixShader':
   vals=[(1450,0),(1490,.01),(1530,.2),(1565,1),(1622,1),(1660,0)]
   if m.name=='Suspended molecular scatter':vals=[(1450,.02),(1510,.12),(1565,.04),(1640,.01),(1660,0)]
   nodekey(node.inputs[0],vals)
for o in s.objects:
 if o.type=='LIGHT':
  e=o.data.energy;o.data.animation_data_clear();key(o.data,'energy',[(1450,e),(1565,e),(1625,e),(1660,0)])
root=bpy.data.objects['DNA · right-handed antiparallel assembly'];root.animation_data_clear()
key(root,'rotation_euler',[(1450,(0,0,.42)),(1565,(0,0,.72)),(1620,(0,0,.83)),(1660,(0,0,.88))])
cam=s.camera;focus=bpy.data.objects['Focus · central complementary pair']
for o in [cam,cam.data,focus]:o.animation_data_clear()
for f,p,target,roll in [(1450,(10,-25,8),(0,0,0),-32),(1469,(10,-25,8),(0,0,0),-32),(1565,(11,-27,8.5),(0,0,0),-34),(1660,(16,-38,12),(0,0,0),-38)]:
 cam.location=p;cam.rotation_euler=((Vector(target)-cam.location).to_track_quat('-Z','Y')@Quaternion((0,0,1),math.radians(roll))).to_euler();focus.location=target
 cam.keyframe_insert('location',frame=f);cam.keyframe_insert('rotation_euler',frame=f);focus.keyframe_insert('location',frame=f)
cam.data.lens=49;cam.data.dof.aperture_fstop=4

# Soft-edged fragments of prior biological textures converge along curved paths.
for i,name in enumerate(['flower','butterfly','iris','cat','leaf','forest']):
 m=bpy.data.materials.new('Biological memory · '+name);m.use_nodes=True;m.surface_render_method='BLENDED';n=m.node_tree.nodes;n.clear();links=m.node_tree.links
 out=n.new('ShaderNodeOutputMaterial');mix=n.new('ShaderNodeMixShader');tr=n.new('ShaderNodeBsdfTransparent');em=n.new('ShaderNodeEmission');em.inputs['Strength'].default_value=.72
 tex=n.new('ShaderNodeTexImage');tex.image=bpy.data.images.load(str(R/'assets'/(name+'.png')));tex.image.filepath='//../assets/'+name+'.png';links.new(tex.outputs['Color'],em.inputs['Color'])
 uv=n.new('ShaderNodeTexCoord');dist=n.new('ShaderNodeVectorMath');dist.operation='DISTANCE';dist.inputs[1].default_value=(.5,.5,0);links.new(uv.outputs['UV'],dist.inputs[0])
 inv=n.new('ShaderNodeMapRange');inv.interpolation_type='SMOOTHSTEP';inv.inputs['From Min'].default_value=.12;inv.inputs['From Max'].default_value=.49;inv.inputs['To Min'].default_value=1;inv.inputs['To Max'].default_value=0;inv.clamp=True;links.new(dist.outputs['Value'],inv.inputs['Value'])
 opacity=n.new('ShaderNodeValue');nodekey(opacity.outputs[0],[(1450,.8),(1469,.8),(1510,.6),(1545,0),(1660,0)])
 mul=n.new('ShaderNodeMath');mul.operation='MULTIPLY';links.new(inv.outputs['Result'],mul.inputs[0]);links.new(opacity.outputs[0],mul.inputs[1]);links.new(mul.outputs[0],mix.inputs[0]);links.new(tr.outputs[0],mix.inputs[1]);links.new(em.outputs[0],mix.inputs[2]);links.new(mix.outputs[0],out.inputs['Surface'])
 bpy.ops.mesh.primitive_plane_add(size=2);o=bpy.context.object;o.name='Organic texture fragment · '+name;o.data.materials.append(m);o.rotation_euler=(math.pi/2,0,0)
 a=i*math.pi/3;p=Vector((6*math.cos(a),-2+i*.23,3*math.sin(a)));mid=Vector((2*math.cos(a+.5),-1.5,math.sin(a+.5)));target=Vector((1.45*math.cos(a),1.45*math.sin(a),0))
 key(o,'location',[(1450,tuple(p)),(1469,tuple(p)),(1510,tuple(mid)),(1545,tuple(target)),(1660,tuple(target))]);key(o,'scale',[(1450,(3.5,1.97,1)),(1469,(3.5,1.97,1)),(1510,(1.5,.85,1)),(1545,(.01,.01,.01)),(1660,(.01,.01,.01))])
s.frame_set(1550);assembly_phase=root.rotation_euler.z
random.seed(820)
for i in range(80):
 m=bpy.data.materials.new('Molecular motes %d'%i);m.use_nodes=True;b=m.node_tree.nodes.get('Principled BSDF');color=(.03,.3,.55,1) if i%2 else (.63,.37,.12,1);b.inputs['Base Color'].default_value=color;b.inputs['Emission Color'].default_value=color;nodekey(b.inputs['Emission Strength'],[(1450,0),(1480,.5),(1520,1.1),(1565,0),(1660,0)])
 a=random.uniform(0,2*math.pi);z=random.uniform(-8,8);p=Vector((random.uniform(5,11)*math.cos(a),random.uniform(-4,4),z));phase=z*2*math.pi/(10.5*.493)+assembly_phase+(0 if i%2 else math.radians(144));q=Vector((1.45*math.cos(phase),1.45*math.sin(phase),z))
 bpy.ops.mesh.primitive_ico_sphere_add(subdivisions=2,radius=random.uniform(.018,.045));o=bpy.context.object;o.name='Molecular convergence · %d'%i;o.data.materials.append(m)
 key(o,'location',[(1450,tuple(p)),(1470+random.randint(0,10),tuple(p)),(1520,tuple((p+q)/2+Vector((0,-1,1)))),(1550,tuple(q)),(1660,tuple(q))])
 key(o,'scale',[(1450,(0,0,0)),(1480,(1,1,1)),(1545,(1,1,1)),(1565,(0,0,0)),(1660,(0,0,0))])
if s.sequence_editor:s.sequence_editor_clear()
s.render.use_sequencer=False;s.render.resolution_percentage=100;s.eevee.taa_render_samples=4;s.render.motion_blur_shutter=.26
for data in list(bpy.data.objects)+list(bpy.data.cameras)+list(bpy.data.materials)+list(bpy.data.lights):
 for block in [data,getattr(data,'node_tree',None)]:
  ad=getattr(block,'animation_data',None)
  if ad and ad.action:
   for fc in ad.action.fcurves:
    for k in fc.keyframe_points:k.handle_left_type='AUTO_CLAMPED';k.handle_right_type='AUTO_CLAMPED'
s['Scientific scope']='Biological images converging into DNA are explicitly an artistic metaphor, not species transforming genetically.'
for idx in [18,19]:
 a=sh[idx];s.frame_start=a['first_frame']-9;s.frame_end=min(1660,a['last_frame']+9);s.frame_set(a['first_frame']);bpy.ops.wm.save_as_mainfile(filepath=str(R/'scenes'/('S%02d_%s.blend'%(idx,a['name']))))
