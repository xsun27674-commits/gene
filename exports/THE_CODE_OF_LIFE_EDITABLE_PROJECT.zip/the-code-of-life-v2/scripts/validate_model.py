"""Run inside the serialized meiosis scene; check biological state transitions."""
import bpy,json
from pathlib import Path
R=Path(__file__).resolve().parents[1];s=bpy.context.scene
names=['M1 · parental','M2 · recombinant','P1 · recombinant','P2 · parental']
actors=[bpy.data.objects[n] for n in names]
s.frame_set(823);bpy.context.view_layer.update();mi=[tuple(o.matrix_world.translation) for o in actors]
assert (actors[0].matrix_world.translation-actors[1].matrix_world.translation).length<1e-5
assert (actors[2].matrix_world.translation-actors[3].matrix_world.translation).length<1e-5
assert actors[0].matrix_world.translation.x<0<actors[2].matrix_world.translation.x
s.frame_set(918);bpy.context.view_layer.update();mii=[tuple(o.matrix_world.translation) for o in actors]
assert len({tuple(round(x,4) for x in p) for p in mii})==4
assert (actors[0].matrix_world.translation-actors[1].matrix_world.translation).length>8
assert (actors[2].matrix_world.translation-actors[3].matrix_world.translation).length>8
recombinant=[]
for actor in actors:
 surface=next(o for o in actor.children if o.type=='MESH');mat=surface.data.materials[0]
 node=mat.node_tree.nodes.get('Distal exchange completion')
 if node:
  assert node.outputs[0].default_value==1
  recombinant.append(actor.name)
assert recombinant==names[1:3]
out={'passed':True,'model':'single homologous pair, 2n=2','meiosis_I_centromere_group_positions':mi,'meiosis_II_product_positions':mii,'chromatids':4,'exchanged_non_sister_chromatids':recombinant,'unchanged_parental_chromatids':[names[0],names[3]],'no_second_replication':True,'four_products_are_not_assumed_all_functional_gametes':True}
(R/'analysis/model_validation.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
