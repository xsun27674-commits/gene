"""Resume individual shots; reuse identical handles within shared 3D scenes."""
from pathlib import Path
import os,json,subprocess,time,shutil
R=Path(__file__).resolve().parents[1];P=json.loads((R/'analysis/plan.json').read_text());SH={x['shot']:x for x in P['shots']}
def producer_running():
 for p in Path('/proc').glob('[0-9]*/cmdline'):
  try:
   a=p.read_bytes().split(b'\0')
   if a and Path(a[0].decode(errors='ignore')).name=='blender' and any(b'S02_DNA_CONTINUATION.blend' in v for v in a):return True
  except (OSError,ValueError):pass
 return False
while producer_running():time.sleep(3)
for idx in [2,3,4,5,6,7,8,9,18,19]:
 sh=SH[idx];out=R/'frames'/('S%02d'%idx);out.mkdir(parents=True,exist_ok=True)
 if idx in [5,6,7,8,9,19]:
  previous=idx-1;old=R/'frames'/('S%02d'%previous)
  for f in range(sh['first_frame']-9,sh['first_frame']+10):
   a=old/('frame_%04d.png'%f);b=out/a.name
   if a.exists() and not b.exists():shutil.copy2(a,b)
 scene=next((R/'scenes').glob('S%02d_*.blend'%idx));env=os.environ.copy();env.update(COL_SHOT=str(idx),LP_NUM_THREADS='4',XDG_CACHE_HOME='/tmp/col-cache')
 with (R/'logs'/('native_S%02d.log'%idx)).open('a') as log:
  subprocess.run(['blender','-b',str(scene),'-t','5','--python',str(R/'scripts/render_shot.py')],env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
 first=max(301,sh['first_frame']-9);end=sh['last_frame']+(0 if idx==19 else 9)
 missing=[f for f in range(first,end+1) if not (out/('frame_%04d.png'%f)).exists()]
 if missing:raise RuntimeError('Missing frames after Blender exit: S%02d %s'%(idx,missing[:5]))
 (R/'analysis/native_status.json').write_text(json.dumps({'completed_shot':idx,'last_frame':end}))
 print('NATIVE_SHOT_COMPLETE S%02d'%idx,flush=True)
print('ALL_NATIVE_COMPLETE',flush=True)
