from pathlib import Path
import json,zipfile,hashlib,shutil
R=Path(__file__).resolve().parents[1]
V=json.loads((R/'delivery/validation.json').read_text());assert V['passed']
model=json.loads((R/'analysis/model_validation.json').read_text());assert model['passed']
movie=R/'delivery/THE_CODE_OF_LIFE_FINAL.mp4'
assert hashlib.sha256(movie.read_bytes()).hexdigest()==V['file_sha256']
report=f'''THE CODE OF LIFE · V2 render report

STATUS: COMPLETE
Music source: user-provided 银牌pp.MP3, AAC audio extracted losslessly; attached video picture not used.
Source audio duration: {V['source_music_duration']:.6f} s
Output duration: {V['video_info']['duration']} s
Resolution / aspect: 1920 x 1080 / 16:9, square pixels
Frame rate / count: 30 FPS / {V['output_video_frames']}
Encoding: H.264 + one AAC stereo 48 kHz audio track
File bytes: {movie.stat().st_size}
Final output path in cloud only: {movie}
Output SHA256: {V['file_sha256']}

Protected intro
- Original MP4 file SHA256 unchanged: {V['original_mp4_sha256']}
- First 300 decoded video frames identical: {V['first_300_decoded_images_identical']}
- First 480000 stereo PCM samples identical: {V['first_480000_stereo_pcm_samples_identical']}
- Camera position, Euler orientation and lens at frame 301 inherit the original scene.
- Original 0–10 s was not rerendered or retimed.

Validation
- Full-file FFmpeg decode with -xerror passed: {V['full_decode_passed']}
- No unintended black frames before ending: {V['no_unexpected_black_frames']}
- No full-frame white flashes: {V['no_full_screen_white_flashes']}
- No unexpected frozen runs: {V['no_unexpected_freezes']}
- Final intentional black hold: {V['end_black_frames']} frames
- Serialized meiosis scene state checks: passed; 2n=2 illustrative model; 2 parental + 2 recombinant chromatids.
- Scientific geometry and montage scope described in README and science/model audit JSON files.

Known limitations / permitted substitutions
- Macro shots 10–17 use generated photographic texture assets with virtual camera movement, not continuous filmed animal video.
- Bird shot 16 uses a transparent generated bird and forest plate in a 2.5D glide composite.
- Molecular/meiotic CGI is schematic, not experimental atomic coordinates or a complete human genome model.
- CPU Eevee rendering; high-speed motion blur and thin-detail sampling can be refined with GPU resources.
- Images are upsampled where needed; output is 1080p, source generated image width is about 1672 pixels.
- AAC splice retains the protected prefix and uses frame-aligned container edits plus encoder preroll.
- Music after the protected intro has 0.88 gain headroom; final 0.6 seconds fade out.

Download verification
- Existing authorized GitHub route was tested before rendering using a 1024-byte HTTP range and matched the original bytes.
- New deliverables will be marked downloadable only after upload and fresh HTTP SHA256 verification.
- Internal workspace paths and handwritten sandbox links are not treated as exported attachments.
'''
(R/'delivery/render_report.txt').write_text(report)
download_proof=R/'analysis/video_download_verification.json'
if download_proof.exists():
 proof=json.loads(download_proof.read_text())
 assert proof['verified'] and proof['sha256']==V['file_sha256']
 report=report.replace('- New deliverables will be marked downloadable only after upload and fresh HTTP SHA256 verification.',f"- Final MP4: fresh HTTPS download verified, {proof['downloaded_bytes']} bytes, SHA256 matched.\n- Verified MP4 URL: {proof['url']}\n- Project/clip ZIP downloads are checked separately after publishing.")
 (R/'delivery/render_report.txt').write_text(report)
if not (R/'requirements.txt').exists():shutil.copy2('/workspace/the-code-of-life/requirements.txt',R/'requirements.txt')
files=[R/'README.md',R/'requirements.txt']
files+=list((R/'scripts').glob('*.py'))+list((R/'scenes').glob('*.blend'))
files+=list((R/'assets').glob('*.png'))+[R/'assets/ORIGINAL_10s.mp4',R/'assets/ORIGINAL_10s.blend']
files += [R/'audio/SOURCE_MUSIC.m4a',R/'audio/first_10s.wav',R/'audio/remainder_master.m4a']
files += [p for p in (R/'analysis').glob('*.json')]+[p for p in (R/'analysis').glob('*.png')]
files += list((R/'analysis').glob('*.csv'))
files += [R/'delivery'/n for n in ['beat_map.csv','shot_list.csv','render_report.txt','validation.json','contact_sheet.jpg']]
files += list((R/'logs').glob('*.log'))
dst=R/'delivery/THE_CODE_OF_LIFE_EDITABLE_PROJECT.zip'
with zipfile.ZipFile(dst,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for name in ['frames','edited_frames','previews','segments','logs','analysis','delivery','scenes','assets','audio']:
  z.writestr('the-code-of-life-v2/'+name+'/',b'')
 for p in files:
  if p.is_file():z.write(p,Path('the-code-of-life-v2')/p.relative_to(R))
with zipfile.ZipFile(dst) as z:assert z.testzip() is None
checks=[]
for p in [movie,dst]:checks.append(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.name)
(R/'delivery/SHA256SUMS.txt').write_text('\n'.join(checks)+'\n')
print('PACKAGED',dst.stat().st_size,'bytes',len(files),'entries')
