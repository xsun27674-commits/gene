"""Continue the original camera. Never render any original frame <=300."""
import bpy,math,json
from pathlib import Path
from mathutils import Vector,Quaternion
R=Path(__file__).resolve().parents[1]
s=bpy.context.scene;c=s.camera;focus=bpy.data.objects['Focus · central complementary pair']
states={}
for f in [299,300,301]:
 s.frame_set(f)
 states[f]={'p':c.location.copy(),'e':c.rotation_euler.copy(),'focus':focus.location.copy(),'lens':c.data.lens,'fstop':c.data.dof.aperture_fstop}
def herm(a,b,m,n,t):return a*(2*t**3-3*t*t+1)+m*(t**3-2*t*t+t)+b*(-2*t**3+3*t*t)+n*(t**3-t*t)
endpos=Vector((-.9,1,18));endfocus=Vector((0,0,20))
ende=((endfocus-endpos).to_track_quat('-Z','Y')@Quaternion((0,0,1),math.radians(-90))).to_euler();ende.make_compatible(states[300]['e'])
look301=(states[301]['focus']-states[301]['p']).to_track_quat('-Z','Y')
roll301=look301.inverted()@states[301]['e'].to_quaternion()
for ob in [c,c.data,focus]:ob.animation_data_clear()
for f in range(300,354):
 t=(f-300)/44
 if f in states:st=states[f];p=st['p'];e=st['e'];q=st['focus'];lens=st['lens'];fs=st['fstop']
 else:
  p=herm(states[300]['p'],endpos,(states[301]['p']-states[300]['p'])*44,Vector((0,0,9)),t)
  q=herm(states[300]['focus'],endfocus,(states[301]['focus']-states[300]['focus'])*44,Vector((0,0,9)),t)
  lens=herm(states[300]['lens'],32,(states[301]['lens']-states[300]['lens'])*44,0,t)
  fs=herm(states[300]['fstop'],3.5,(states[301]['fstop']-states[300]['fstop'])*44,0,t)
  blend=max(0,min(1,(f-301)/43));blend=blend*blend*(3-2*blend)
  roll=roll301.slerp(Quaternion((0,0,1),math.radians(-90)),blend)
  e=((q-p).to_track_quat('-Z','Y')@roll).to_euler('XYZ',states[301]['e'])
 c.location=p;c.rotation_euler=e;focus.location=q;c.data.lens=lens;c.data.dof.aperture_fstop=fs
 c.keyframe_insert('location',frame=f);c.keyframe_insert('rotation_euler',frame=f);focus.keyframe_insert('location',frame=f)
 c.data.keyframe_insert('lens',frame=f);c.data.dof.keyframe_insert('aperture_fstop',frame=f)
for ob in [c,c.data,focus]:
 for fc in ob.animation_data.action.fcurves:
  for k in fc.keyframe_points:k.interpolation='LINEAR'
root=bpy.data.objects['DNA · right-handed antiparallel assembly']
ext=bpy.data.objects.new('Physically continuous DNA extension · 50 base pairs',None);s.collection.objects.link(ext);ext.parent=root;ext.location=(0,0,24.65);ext.rotation_euler.z=50*2*math.pi/10.5
for ob in list(s.objects):
 if ob.parent==root and ob!=ext:
  clone=ob.copy();clone.data=ob.data.copy();s.collection.objects.link(clone);clone.parent=ext
for ob in s.objects:
 if ob.name.startswith('Assembly microstructure'):ob.hide_render=True
for mat in bpy.data.materials:
 if not mat.use_nodes:continue
 nodes=mat.node_tree.nodes
 if mat.name.startswith(('5prime','3prime','Complementary','Hydrogen')):
  out=nodes.get('Material Output');bs=nodes.get('Principled BSDF');mat.node_tree.links.new(bs.outputs[0],out.inputs['Surface'])
if s.sequence_editor:s.sequence_editor_clear()
s.render.use_sequencer=False;s.render.resolution_percentage=100;s.render.fps=30;s.frame_start=301;s.frame_end=353;s.eevee.taa_render_samples=8
s['continuity']='Original camera samples 300/301 retained exactly. DNA extended by 50 bp with matching axial rise and twist; original MP4 unchanged.'
s.frame_set(301)
audit={'camera_300':list(states[300]['p']),'camera_301':list(c.location),'inherited_velocity_per_frame':list(states[301]['p']-states[300]['p']),'original_rotation_301':list(states[301]['e']),'actual_rotation_301':list(c.rotation_euler),'original_lens_301':states[301]['lens'],'actual_lens_301':c.data.lens,'original_frames_rendered':False}
assert (c.location-states[301]['p']).length<1e-6
(R/'analysis/continuity_camera.json').write_text(json.dumps(audit,indent=2))
bpy.ops.wm.save_as_mainfile(filepath=str(R/'scenes/S02_DNA_CONTINUATION.blend'))
