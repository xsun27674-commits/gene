"""Reproduce the music master without altering the protected intro AAC."""
from pathlib import Path
import subprocess,json
R=Path(__file__).resolve().parents[1]
def run(a):subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y']+a,check=True)
run(['-i',str(R/'audio/SOURCE_MUSIC.m4a'),'-ac','2','-ar','48000','-c:a','pcm_f32le',str(R/'audio/full_music_float.wav')])
run(['-i',str(R/'audio/SOURCE_MUSIC.m4a'),'-ac','1','-ar','22050','-c:a','pcm_s16le',str(R/'audio/analysis.wav')])
run(['-ss','9.984','-i',str(R/'audio/full_music_float.wav'),'-t','45.344345','-af','volume=0.88,afade=t=out:st=44.744345:d=0.6','-c:a','aac','-b:a','256k','-ar','48000',str(R/'audio/remainder_master.m4a')])
run(['-i',str(R/'assets/ORIGINAL_10s.mp4'),'-map','0:a:0','-c:a','copy','-f','adts',str(R/'audio/intro_encoded.aac')])
run(['-i',str(R/'audio/remainder_master.m4a'),'-c:a','copy','-f','adts',str(R/'audio/remainder_encoded.aac')])
(R/'audio/combined_encoded.aac').write_bytes((R/'audio/intro_encoded.aac').read_bytes()+(R/'audio/remainder_encoded.aac').read_bytes())
print('Music master prepared: protected intro unchanged; new remainder has AAC preroll, -1.11 dB gain and 0.6 s tail fade.')
