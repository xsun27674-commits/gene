"""Science-directed CGI: nucleosome organization and meiosis in a 2n=2 model.
All genetics geometry is schematic, not atomic coordinate reconstruction.
"""
import bpy,math,random,json,sys
from pathlib import Path
from mathutils import Vector,Matrix
R=Path(__file__).resolve().parents[1]
PLAN=json.loads((R/'analysis/plan.json').read_text());SH={x['shot']:x for x in PLAN['shots']}
kind=sys.argv[sys.argv.index('--')+1] if '--' in sys.argv else 'science'
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
s=bpy.context.scene;s.render.engine='BLENDER_EEVEE_NEXT';s.eevee.taa_render_samples=4
s.eevee.shadow_resolution_scale=.5;s.eevee.use_raytracing=False
s.render.resolution_x=1920;s.render.resolution_y=1080;s.render.resolution_percentage=100;s.render.fps=30
s.render.threads_mode='FIXED';s.render.threads=5;s.render.use_motion_blur=True;s.render.motion_blur_shutter=.28
s.render.image_settings.file_format='PNG';s.render.image_settings.color_mode='RGB';s.render.film_transparent=False
s.world.use_nodes=True;s.world.node_tree.nodes['Background'].inputs['Color'].default_value=(.001,.003,.009,1);s.world.node_tree.nodes['Background'].inputs['Strength'].default_value=.1
s.view_settings.view_transform='AgX'
def material(name,color,rough=.34,em=.02,organic=False):
 m=bpy.data.materials.new(name);m.use_nodes=True;b=m.node_tree.nodes.get('Principled BSDF');b.inputs['Base Color'].default_value=(*color,1);b.inputs['Metallic'].default_value=.3;b.inputs['Roughness'].default_value=rough;b.inputs['Emission Color'].default_value=(*color,1);b.inputs['Emission Strength'].default_value=em
 if organic:
  n=m.node_tree.nodes.new('ShaderNodeTexNoise');n.inputs['Scale'].default_value=24;n.inputs['Detail'].default_value=5
  bump=m.node_tree.nodes.new('ShaderNodeBump');bump.inputs['Strength'].default_value=.28;bump.inputs['Distance'].default_value=.045;m.node_tree.links.new(n.outputs['Fac'],bump.inputs['Height']);m.node_tree.links.new(bump.outputs[0],b.inputs['Normal'])
 return m
BLUE=(.022,.23,.43);GOLD=(.53,.31,.1)
blue=material('Maternal chromatin · blue',BLUE,organic=True);gold=material('Paternal chromatin · champagne',GOLD,organic=True)
neutral=material('Protein cohesion · pale champagne',(.3,.26,.17),.4,.01,True)
guide=material('Cell membrane · quiet optical rim',(.025,.12,.19),.6,.8)
fiber=material('Spindle microtubules',(.055,.17,.22),.6,.25)
def sphere(name,p,r,m,scale=(1,1,1),parent=None):
 bpy.ops.mesh.primitive_uv_sphere_add(segments=20,ring_count=12,radius=r,location=p);o=bpy.context.object;o.name=name;o.scale=scale;o.data.materials.append(m);o.parent=parent
 for f in o.data.polygons:f.use_smooth=True
 return o
def curve(name,pts,r,m,parent=None):
 d=bpy.data.curves.new(name,'CURVE');d.dimensions='3D';d.bevel_depth=r;d.bevel_resolution=3;p=d.splines.new('POLY');p.points.add(len(pts)-1)
 for q,v in zip(p.points,pts):q.co=(*v,1)
 o=bpy.data.objects.new(name,d);s.collection.objects.link(o);o.data.materials.append(m);o.parent=parent;return o
def empty(name):o=bpy.data.objects.new(name,None);s.collection.objects.link(o);return o
def key(o,path,vals):
 for f,v in vals:setattr(o,path,v);o.keyframe_insert(path,frame=f)
def alpha(m,vals):
 ns=m.node_tree.nodes;mix=ns.new('ShaderNodeMixShader');tr=ns.new('ShaderNodeBsdfTransparent');out=ns.get('Material Output');bs=ns.get('Principled BSDF');ls=m.node_tree.links;ls.new(tr.outputs[0],mix.inputs[1]);ls.new(bs.outputs[0],mix.inputs[2]);ls.new(mix.outputs[0],out.inputs['Surface'])
 for f,v in vals:mix.inputs[0].default_value=v;mix.inputs[0].keyframe_insert('default_value',frame=f)
def area(name,p,c,e,size,shadow=True):
 d=bpy.data.lights.new(name,'AREA');d.energy=e;d.color=c;d.shape='DISK';d.size=size;d.use_shadow=shadow;o=bpy.data.objects.new(name,d);s.collection.objects.link(o);o.location=p;o.rotation_euler=(-o.location).to_track_quat('-Z','Y').to_euler()
area('Sapphire key',(-6,-9,7),(.3,.65,1),1700,8)
area('Champagne contour',(5,4,6),(1,.68,.32),1600,7,False)
area('Gentle neutral fill',(7,-10,-3),(.65,.78,1),330,10,False)
d=bpy.data.cameras.new('Cinematic science camera');cam=bpy.data.objects.new('Cinematic science camera',d);s.collection.objects.link(cam);s.camera=cam
focus=empty('Scientific focus');d.dof.use_dof=True;d.dof.focus_object=focus;d.dof.aperture_fstop=5.6
def camera(f,loc,target,lens=52,roll=0):
 cam.location=loc;cam.rotation_euler=(Vector(target)-cam.location).to_track_quat('-Z','Y').to_euler();cam.rotation_euler.rotate_axis('Z',roll);d.lens=lens;focus.location=target
 cam.keyframe_insert('location',frame=f);cam.keyframe_insert('rotation_euler',frame=f);d.keyframe_insert('lens',frame=f);focus.keyframe_insert('location',frame=f)
def compositor():
 s.use_nodes=True;n=s.node_tree.nodes;n.clear();rl=n.new('CompositorNodeRLayers');g=n.new('CompositorNodeGlare');g.glare_type='FOG_GLOW';g.quality='HIGH';g.threshold=2;out=n.new('CompositorNodeComposite');s.node_tree.links.new(rl.outputs['Image'],g.inputs['Image']);s.node_tree.links.new(g.outputs['Image'],out.inputs[0])
compositor()

if kind=='chromatin':
 # Each histone core has 8 protein lobes. The DNA centreline winds LEFT-handed
 # around the core ~1.65 times; its own local duplex remains right handed.
 wrapmat=material('DNA backbone · nucleosome blue',(.03,.29,.48),.28,.05)
 basemat=material('DNA bases · nucleosome warm',(.37,.29,.12),.35,.02)
 for j in range(-2,4):
  center=Vector((j*3.6,0,math.sin(j*.8)*.3))
  for k in range(8):
   a=k*math.pi/2;z=.24 if k<4 else -.24
   sphere('Histone octamer %d · subunit %d'%(j,k),center+Vector((.4*math.cos(a),.4*math.sin(a),z)),.57,neutral,scale=(1,1,.7))
  rails=[[],[]]
  for k in range(501):
   t=k/500;ang=math.pi-2*math.pi*1.65*t
   p=center+Vector((1.15*math.cos(ang),1.15*math.sin(ang),-.45+.9*t))
   normal=Vector((math.cos(ang),math.sin(ang),0));tangent=Vector((1.15*2*math.pi*1.65*math.sin(ang),-1.15*2*math.pi*1.65*math.cos(ang),.9)).normalized();binormal=tangent.cross(normal).normalized()
   for strand in [0,1]:
    ph=2*math.pi*14*t+strand*math.radians(144)
    rails[strand].append(p+.2*(normal*math.cos(ph)+binormal*math.sin(ph)))
  for strand in [0,1]:curve('Nucleosome %d antiparallel DNA rail %d'%(j,strand),rails[strand],.035,wrapmat if strand==0 else basemat)
  # 147 complementary base-pair rungs per wrapped nucleosomal segment.
  for k in range(147):
   idx=round(k*500/146);curve('Wrapped base pair', [rails[0][idx],rails[1][idx]],.012,basemat)
  if j<3:
   nextcenter=Vector(((j+1)*3.6,0,math.sin((j+1)*.8)*.3));a0=math.pi-2*math.pi*1.65;a1=math.pi
   p0=center+Vector((1.15*math.cos(a0),1.15*math.sin(a0),.45));p3=nextcenter+Vector((1.15*math.cos(a1),1.15*math.sin(a1),-.45))
   def frame(a):
    n=Vector((math.cos(a),math.sin(a),0));t=Vector((1.15*2*math.pi*1.65*math.sin(a),-1.15*2*math.pi*1.65*math.cos(a),.9)).normalized();b=t.cross(n).normalized();return t,Matrix((n,b,t)).transposed().to_quaternion()
   t0,q0=frame(a0);t1,q1=frame(a1);p1=p0+t0*.65;p2=p3-t1*.65;linkrails=[[],[]]
   for k in range(161):
    t=k/160;p=(1-t)**3*p0+3*(1-t)**2*t*p1+3*(1-t)*t*t*p2+t**3*p3;q=q0.slerp(q1,t)
    for strand in [0,1]:
     ph=6*math.pi*t+strand*math.radians(144);linkrails[strand].append(p+q@Vector((.2*math.cos(ph),.2*math.sin(ph),0)))
   for strand in [0,1]:curve('Continuous antiparallel linker rail',linkrails[strand],.035,wrapmat if strand==0 else basemat)
   for k in range(32):
    idx=round(k*160/31);curve('Linker complementary base pair',[linkrails[0][idx],linkrails[1][idx]],.012,basemat)
 camera(336,(2,-5,3),(0,0,0),52,.15)
 camera(345,(2,-5,3),(0,0,0),52,.15)
 camera(380,(5,-11,7),(1,0,0),48,.07)
 camera(417,(10,-19,10),(2,0,0),46,0)
 s['Scientific audit']='DNA duplex -> ~1.65 left-handed wraps around 8-subunit histone core -> nucleosomal chromatin. 147 schematic base pairs per core. Higher-order packing is schematic, not a universal 30 nm solenoid.'
 shot=SH[3];s.frame_start=shot['first_frame']-9;s.frame_end=shot['last_frame']+9;s.frame_set(shot['first_frame']);bpy.ops.wm.save_as_mainfile(filepath=str(R/'scenes/S03_CHROMATIN.blend'))

elif kind=='science':
 roots=[empty('Maternal replicated homologue'),empty('Paternal replicated homologue')]
 exchange_frame=round(20.2478*30)+1
 def chromatid(name,parent,side,base,recombined=False,flip=False):
  actor=empty(name);actor.parent=parent
  n=150;k=24;verts=[];faces=[];attributes=[];cross=[]
  for i in range(n+1):
   t=-1+2*i/n;cx=side*(.14+.83*abs(t)**1.25);cz=t*3.25
   radius=.37*max(0,math.sin(math.pi*i/n))**.3*(.58+.42*(1-math.exp(-t*t/.025)))
   dxds=side*.83*1.25*(1 if t>=0 else -1)*abs(t)**.25
   normal=Vector((3.25,0,-dxds)).normalized();binormal=Vector((0,1,0))
   delta=(1.57 if side>0 else -1.57)*math.exp(-((t-.35)/.17)**2) if recombined else 0
   crossnormal=Vector((3.25,0,-dxds-delta*(-2*(t-.35)/(.17**2)))).normalized()
   for j in range(k):
    a=j*2*math.pi/k;r=radius*(1+.14*math.sin(13*a+31*t)+.08*math.sin(7*a-53*t))
    v=Vector((cx,0,cz))+normal*(r*math.cos(a))+binormal*(r*math.sin(a));verts.append(tuple(v));attributes.append(t)
    cv=Vector((cx+delta,(.38 if side>0 else -.38)*math.exp(-((t-.35)/.15)**2),cz))+crossnormal*(r*math.cos(a))+binormal*(r*math.sin(a));cross.append(tuple(cv))
  for i in range(n):
   for j in range(k):a=i*k+j;b=i*k+(j+1)%k;faces.append((a,b,b+k,a+k))
  mesh=bpy.data.meshes.new(name);mesh.from_pydata(verts,[],faces);mesh.update();ob=bpy.data.objects.new(name+' · chromatin fibre surface',mesh);s.collection.objects.link(ob);ob.parent=actor
  for p in mesh.polygons:p.use_smooth=True
  attr=mesh.attributes.new('homologous_arm_position','FLOAT','POINT')
  for a,t in zip(attr.data,attributes):a.value=t
  m=(base.copy() if recombined else base);ob.data.materials.append(m)
  if recombined:
   m.name=name+' · exchanged distal segment';ns=m.node_tree.nodes;ls=m.node_tree.links;bs=ns.get('Principled BSDF')
   a=ns.new('ShaderNodeAttribute');a.attribute_name='homologous_arm_position';gt=ns.new('ShaderNodeMath');gt.operation='GREATER_THAN';gt.inputs[1].default_value=.35;ls.new(a.outputs['Fac'],gt.inputs[0]);v=ns.new('ShaderNodeValue');v.name='Distal exchange completion'
   for f,value in [(1,0),(exchange_frame-5,0),(exchange_frame,1),(1660,1)]:v.outputs[0].default_value=value;v.outputs[0].keyframe_insert('default_value',frame=f)
   mul=ns.new('ShaderNodeMath');mul.operation='MULTIPLY';ls.new(gt.outputs[0],mul.inputs[0]);ls.new(v.outputs[0],mul.inputs[1]);mix=ns.new('ShaderNodeMixRGB');mix.inputs[1].default_value=(*(GOLD if flip else BLUE),1);mix.inputs[2].default_value=(*(BLUE if flip else GOLD),1);ls.new(mul.outputs[0],mix.inputs[0]);ls.new(mix.outputs[0],bs.inputs['Base Color']);ls.new(mix.outputs[0],bs.inputs['Emission Color'])
   ob.shape_key_add(name='Aligned homologous arm');sk=ob.shape_key_add(name='Non-sister chiasma')
   for p,vv in zip(sk.data,cross):p.co=vv
   for f,value in [(1,0),(SH[6]['first_frame'],0),(exchange_frame-8,1),(exchange_frame+15,1),(SH[6]['last_frame'],0),(1660,0)]:sk.value=value;sk.keyframe_insert('value',frame=f)
  # Fine polymer winding is part of the chromatid surface, not extra chromatids.
  for w in range(2):
   pts=[]
   for i in range(321):
    t=-.97+1.94*i/320;r=.22*(math.sin(math.pi*(i+2)/324))**.3*(.6+.4*(1-math.exp(-t*t/.025)));a=i*.53+w*math.pi
    pts.append((side*(.14+.83*abs(t)**1.25)+r*math.cos(a),r*math.sin(a),3.25*t))
   if not recombined:curve(name+' folded chromatin winding',pts,.012,base,actor)
  return actor
 actors=[chromatid('M1 · parental',roots[0],-1,blue),chromatid('M2 · recombinant',roots[0],1,blue,True),chromatid('P1 · recombinant',roots[1],-1,gold,True,True),chromatid('P2 · parental',roots[1],1,gold)]
 # Two intact sister pairs until meiosis II. The bivalent model is 2n=2.
 key(roots[0],'location',[(1,(0,0,0)),(SH[4]['last_frame'],(0,0,0)),(SH[5]['last_frame'],(-1.8,0,0)),(SH[8]['first_frame'],(-1.8,0,0)),(SH[8]['last_frame'],(-5.4,0,0)),(1660,(-5.4,0,0))])
 key(roots[1],'location',[(1,(18,0,0)),(SH[5]['first_frame'],(18,0,0)),(SH[5]['last_frame'],(1.8,0,0)),(SH[8]['first_frame'],(1.8,0,0)),(SH[8]['last_frame'],(5.4,0,0)),(1660,(5.4,0,0))])
 for i,o in enumerate(actors):
  dz=4.6 if i in [0,2] else -4.6
  key(o,'location',[(1,(0,0,0)),(SH[9]['first_frame'],(0,0,0)),(SH[9]['last_frame']-23,(0,0,dz)),(1660,(0,0,dz))])
 for i,parent in enumerate(roots):
  o=sphere('Cohesin / centromere connection',(.0,0,0),.17,neutral,scale=(1.8,.8,.7),parent=parent)
  key(o,'scale',[(1,(1.8,.8,.7)),(SH[9]['first_frame'],(1.8,.8,.7)),(SH[9]['first_frame']+10,(0,0,0)),(1660,(0,0,0))])
 # Quiet cell boundaries separate homologues first, then individual chromatids.
 def cell(name,x,z,r,vals):
  pts=[(x+r*math.cos(k*2*math.pi/240),.8,z+r*math.sin(k*2*math.pi/240)) for k in range(241)]
  m=guide.copy();m.name=name+' membrane';alpha(m,vals);return curve(name,pts,.018,m)
 cell('Diploid cell',0,0,7.4,[(1,0),(SH[7]['first_frame'],0),(SH[7]['first_frame']+28,.4),(SH[8]['first_frame'],.45),(SH[8]['last_frame'],0),(1660,0)])
 for x in [-5.4,5.4]:
  cell('Meiosis I product',x,0,4.2,[(1,0),(SH[8]['first_frame'],0),(SH[8]['last_frame']-6,.55),(SH[9]['first_frame']+4,.55),(SH[9]['last_frame']-20,0),(1660,0)])
  for z in [-4.6,4.6]:cell('Haploid product',x,z,3.9,[(1,0),(SH[9]['first_frame']+8,0),(SH[9]['last_frame']-23,.65),(1660,.65)])
 # Non-sister exchange highlight is localized to the chiasma, not a white flash.
 glow=material('Chiasma protein-scale accent',(.38,.6,.67),.4,1.1)
 o=sphere('Localized crossover accent',(0,0,1.14),.17,glow)
 key(o,'scale',[(1,(0,0,0)),(exchange_frame-5,(0,0,0)),(exchange_frame,(1,1,1)),(exchange_frame+7,(0,0,0)),(1660,(0,0,0))])
 # Focus and orbit changes are intentional, anchored to musical boundaries.
 for f,p,q,l in [
  (400,(-11,-22,5),(0,0,0),53),(409,(-11,-22,5),(0,0,0),53),(495,(11,-22,5),(0,0,0),53),
  (496,(11,-22,5),(0,0,0),53),(567,(10,-26,5),(0,0,0),53),
  (568,(10,-26,5),(0,0,0),53),(608,(5,-20,3),(0,0,1.1),58),(671,(6,-22,4),(0,0,.7),55),
  (672,(6,-22,4),(0,0,.7),55),(751,(9,-29,5),(0,0,0),52),
  (752,(9,-29,5),(0,0,0),52),(823,(8,-35,5),(0,0,0),45),
  (824,(8,-35,5),(0,0,0),45),(918,(6,-39,6),(0,0,0),39),(927,(6,-39,6),(0,0,0),39)]:camera(f,p,q,l)
 s['Scientific audit']='2n=2 pedagogical model. Four chromatids: M1 blue parental; M2 blue with gold distal exchange; P1 gold with blue distal exchange; P2 gold parental. Crossing over only M2/P1 in prophase I. Meiosis I separates homologues with sisters paired. Meiosis II separates sisters into four n=1 products. No claim that all products become functional gametes.'
 audit={'diploid_model_2n':2,'chromatids':4,'recombinant_chromatids':['M2','P1'],'unchanged_chromatids':['M1','P2'],'exchange_is_between_non_sisters':True,'exchange_complete_frame':exchange_frame,'meiosis_I_separates':'homologues','meiosis_II_separates':'sisters','haploid_products':4}
 (R/'analysis/science_audit.json').write_text(json.dumps(audit,indent=2))
 for idx in range(4,10):
  sh=SH[idx];s.frame_start=sh['first_frame']-9;s.frame_end=sh['last_frame']+9;s.frame_set(sh['first_frame'])
  bpy.ops.wm.save_as_mainfile(filepath=str(R/'scenes'/('S%02d_%s.blend'%(idx,sh['name']))))

# Clamp all ordinary animations to prevent overshoots in cell fates and color.
for data in list(bpy.data.objects)+list(bpy.data.cameras)+list(bpy.data.materials):
 for block in [data,getattr(data,'node_tree',None)]:
  ad=getattr(block,'animation_data',None)
  if ad and ad.action:
   for fc in ad.action.fcurves:
    for k in fc.keyframe_points:k.handle_left_type='AUTO_CLAMPED';k.handle_right_type='AUTO_CLAMPED'
if kind=='chromatin':
 s.frame_set(SH[3]['first_frame']);bpy.ops.wm.save_as_mainfile(filepath=str(R/'scenes/S03_CHROMATIN.blend'))
elif kind=='science':
 for idx in range(4,10):
  sh=SH[idx];s.frame_start=sh['first_frame']-9;s.frame_end=sh['last_frame']+9;s.frame_set(sh['first_frame']);bpy.ops.wm.save_as_mainfile(filepath=str(R/'scenes'/('S%02d_%s.blend'%(idx,sh['name']))))
