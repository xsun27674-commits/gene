"""Resumable segment renderer. Original frames <=300 are never rendered."""
import bpy,json,os,time,shutil
from pathlib import Path
R=Path(__file__).resolve().parents[1];s=bpy.context.scene
preview=os.environ.get('COL_PREVIEW','0')=='1'
shot=int(os.environ['COL_SHOT']);sh=json.loads((R/'analysis/plan.json').read_text())['shots'][shot-1]
out=R/('previews' if preview else 'frames')/('S%02d'%shot);out.mkdir(parents=True,exist_ok=True)
if preview:
 s.render.resolution_percentage=50;s.eevee.taa_render_samples=2
else:s.render.resolution_percentage=100
# S02 inherits original frame numbers; all other shots carry 9-frame handles.
start=max(301,sh['first_frame']-9);end=sh['last_frame']+9
if shot==19:end=sh['last_frame']
if 'COL_ONLY_FRAMES' in os.environ:
 frames=[int(x) for x in os.environ['COL_ONLY_FRAMES'].split(',')]
else:frames=list(range(start,end+1,3 if preview else 1))
if preview:
 for f in frames:
  s.frame_set(f);s.render.filepath=str(out/('frame_%04d.png'%f));bpy.ops.render.render(write_still=True);print('PREVIEW S%02d f%d'%(shot,f),flush=True)
else:
 # Do not alter the original look of continuation; new science scenes use 4 samples.
 if shot==2:s.eevee.taa_render_samples=8
 if shot==19:
  # The last 11 frames are an intentional post-production black hold. Do not
  # spend CPU shading an invisible scene that the compositor replaces with black.
  firstblack=out/'frame_1650.png'
  if not firstblack.exists():
   im=bpy.data.images.new('Intentional final black hold',width=1920,height=1080,alpha=False)
   im.generated_color=(0,0,0,1);im.file_format='PNG';im.filepath_raw=str(firstblack);im.save();bpy.data.images.remove(im)
  for f in range(1651,1661):
   dst=out/('frame_%04d.png'%f)
   if not dst.exists():shutil.copy2(firstblack,dst)
  print('COMPOSITED_BLACK_HOLD 1650-1660',flush=True)
  def optimize_opaque(scene,*args):
   for mat in bpy.data.materials:
    if not mat.use_nodes or not mat.name.startswith(('5prime','3prime','Complementary','Hydrogen')):continue
    ns=mat.node_tree.nodes;mix=next((n for n in ns if n.bl_idname=='ShaderNodeMixShader'),None)
    if not mix:continue
    outnode=ns.get('Material Output');bs=ns.get('Principled BSDF')
    desired=bs.outputs[0] if mix.inputs[0].default_value>=.999999 else mix.outputs[0]
    links=outnode.inputs['Surface'].links
    if not links or links[0].from_socket!=desired:mat.node_tree.links.new(desired,outnode.inputs['Surface'])
  bpy.app.handlers.frame_change_post.append(optimize_opaque)
 while frames and (out/('frame_%04d.png'%frames[0])).exists():frames.pop(0)
 if frames:
  s.frame_start=frames[0];s.frame_end=frames[-1];s.render.filepath=str(out/'frame_');s.render.use_sequencer=False
  s.render.use_overwrite=False
  begin=time.monotonic()
  def wrote(scene,*a):print('PROGRESS S%02d %d/%d %.1fs'%(shot,scene.frame_current,end,time.monotonic()-begin),flush=True)
  bpy.app.handlers.render_write.append(wrote)
  bpy.ops.render.render(animation=True)
 print('SHOT_COMPLETE S%02d'%shot,flush=True)
