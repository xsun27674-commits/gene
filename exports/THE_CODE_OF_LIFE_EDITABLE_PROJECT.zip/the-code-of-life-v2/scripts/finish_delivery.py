"""Resume final assembly only after every native scene has completed."""
from pathlib import Path
import subprocess,sys,time,os
R=Path(__file__).resolve().parents[1]
deadline=time.monotonic()+1800
while 'ALL_NATIVE_COMPLETE' not in (R/'logs/native_pipeline.log').read_text():
 if time.monotonic()>deadline:raise TimeoutError('Native render not complete; assembly not started.')
 time.sleep(10)
if os.environ.get('COL_WAIT_CAMERA_FIX'):
 while 'Blender quit' not in (R/'logs/native_S02_camera_fixed.log').read_text():
  if time.monotonic()>deadline:raise TimeoutError('Camera repair not complete.')
  time.sleep(10)
for name in ['compose_frames.py','export_final.py','validate_final.py','package_project.py']:
 print('START',name,flush=True)
 with (R/'logs'/('final_'+name.removesuffix('.py')+'.log')).open('w') as log:
  subprocess.run([sys.executable,str(R/'scripts'/name)],stdout=log,stderr=subprocess.STDOUT,check=True)
 print('COMPLETE',name,flush=True)
print('DELIVERY_READY',flush=True)
