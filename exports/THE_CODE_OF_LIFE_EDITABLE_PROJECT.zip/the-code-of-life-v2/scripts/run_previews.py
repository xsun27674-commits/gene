import subprocess,os,json
from pathlib import Path
R=Path(__file__).resolve().parents[1]
jobs=[(2,range(301,354,3)),(3,range(336,418,3)),(4,range(400,928,3)),(18,range(1460,1661,3))]
for idx,frames in jobs:
 scene=next((R/'scenes').glob('S%02d_*.blend'%idx));env=os.environ.copy();env.update(COL_PREVIEW='1',COL_SHOT=str(idx),COL_ONLY_FRAMES=','.join(map(str,frames)),LP_NUM_THREADS='4',XDG_CACHE_HOME='/tmp/col-cache')
 with (R/'logs'/('preview_anim_S%02d.log'%idx)).open('w') as log:
  subprocess.run(['blender','-b',str(scene),'-t','5','--python',str(R/'scripts/render_shot.py')],env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
 print('PREVIEW_ANIMATION_COMPLETE S%02d'%idx,flush=True)
print('ALL_PREVIEWS_COMPLETE',flush=True)
