from pathlib import Path
import subprocess,json,hashlib,csv,sys
from PIL import Image,ImageStat,ImageDraw,ImageFont
import numpy as np
R=Path(__file__).resolve().parents[1];P=json.loads((R/'analysis/plan.json').read_text());movie=R/'delivery/THE_CODE_OF_LIFE_FINAL.mp4';intro=R/'assets/ORIGINAL_10s.mp4'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def pcm_prefix(p):return subprocess.check_output(['ffmpeg','-v','error','-i',str(p),'-map','0:a:0','-af','atrim=end_sample=480000','-f','f32le','-'])
def frame_hashes(p):
 raw=subprocess.check_output(['ffmpeg','-v','error','-i',str(p),'-map','0:v:0','-an','-frames:v','300','-f','framemd5','-'],text=True)
 return [v.split(',')[-1].strip() for v in raw.splitlines() if v and not v.startswith('#')]
data=json.loads(subprocess.check_output(['ffprobe','-v','error','-count_frames','-show_entries','format=duration,size:stream=codec_type,codec_name,width,height,pix_fmt,sample_aspect_ratio,display_aspect_ratio,r_frame_rate,avg_frame_rate,nb_read_frames,duration,sample_rate,channels,start_time','-of','json',str(movie)],text=True))
v=next(a for a in data['streams'] if a['codec_type']=='video');a=next(a for a in data['streams'] if a['codec_type']=='audio')
assert (v['width'],v['height'],v['codec_name'],v['r_frame_rate'],int(v['nb_read_frames']))==(1920,1080,'h264','30/1',P['frames'])
assert v['sample_aspect_ratio']=='1:1' and v['display_aspect_ratio']=='16:9'
assert a['codec_name']=='aac' and a['sample_rate']=='48000' and a['channels']==2
assert abs(float(data['format']['duration'])-P['video_duration'])<.0001
assert abs(float(a['duration'])-P['source_duration'])<.001
assert float(v['start_time'])==0 and float(a['start_time'])==0
expected='9f68afe66279723490707d1ced6c09a12a25bf2567b83ac7c04659c47e580964'
assert sha(intro)==expected,'Protected original file has changed.'
old_frames=frame_hashes(intro);new_frames=frame_hashes(movie)
assert len(new_frames)==300 and old_frames==new_frames,'Protected image prefix differs.'
old_pcm=pcm_prefix(intro);new_pcm=pcm_prefix(movie)
assert len(new_pcm)==3840000 and old_pcm==new_pcm,'Protected audio prefix differs.'
subprocess.run(['ffmpeg','-v','error','-xerror','-i',str(movie),'-f','null','-'],check=True)
shs=P['shots'];means={};duplicates=[];last=None;run=0;flashes=[];black=[]
for f in range(301,P['frames']+1):
 p=R/'edited_frames'/('frame_%04d.png'%f)
 with Image.open(p) as im:
  im.verify()
 with Image.open(p) as im:
  assert im.size==(1920,1080)
  thumb=im.resize((96,54));arr=np.asarray(thumb).astype(float);m=float(arr.mean());means[f]=m
  if f<1620 and m<.1:black.append(f)
  if (arr.min(axis=2)>245).mean()>.8:flashes.append(f)
  h=hashlib.sha256(im.tobytes()).digest()
  run=run+1 if h==last else 0
  if run>=5 and f<1620:duplicates.append(f)
  last=h
assert not black,('Unintended black frames',black)
assert not flashes,('Full-frame white flashes',flashes)
assert not duplicates,('Unexpected freeze',duplicates)
for f in range(1650,P['frames']+1):
 with Image.open(R/'edited_frames'/('frame_%04d.png'%f)) as im:assert im.getextrema()==((0,0),(0,0),(0,0))
seams=[]
for sh in shs[:-1]:
 b=sh['last_frame'];seams.append({'boundary_seconds':b/30,'left_frame':b,'right_frame':b+1,'left_mean_rgb':means.get(b),'right_mean_rgb':means.get(b+1),'next_shot':shs[sh['shot']]['name']})
proof={'passed':True,'original_mp4_sha256':expected,'first_300_decoded_images_identical':True,'first_480000_stereo_pcm_samples_identical':True,'audio_prefix_sha256':hashlib.sha256(old_pcm).hexdigest(),'frame_prefix_hash_list_sha256':hashlib.sha256('\n'.join(old_frames).encode()).hexdigest(),'full_decode_passed':True,'no_unexpected_black_frames':True,'no_full_screen_white_flashes':True,'no_unexpected_freezes':True,'end_black_frames':11,'source_music_duration':P['source_duration'],'output_video_frames':P['frames'],'video_info':v,'audio_info':a,'file_size_bytes':movie.stat().st_size,'file_sha256':sha(movie),'seams':seams}
(R/'delivery/validation.json').write_text(json.dumps(proof,indent=2))
# Diagnostic contact sheet only: labels are NOT part of the movie.
thumbs=Image.new('RGB',(1280,10*390),(3,6,12));font=ImageFont.load_default(size=15)
for i,sh in enumerate(shs):
 f=round((sh['first_frame']+sh['last_frame'])/2)
 if sh['shot']==1:
  p=R/'previews/intro_midpoint.png';p.parent.mkdir(parents=True,exist_ok=True)
  subprocess.run(['ffmpeg','-v','error','-y','-ss',str((f-1)/30),'-i',str(intro),'-frames:v','1','-update','1',str(p)],check=True)
 else:p=R/'edited_frames'/('frame_%04d.png'%f)
 if p.exists():
  with Image.open(p) as im:im=im.resize((640,360),Image.Resampling.LANCZOS);x=(i%2)*640;y=(i//2)*390;thumbs.paste(im,(x,y));ImageDraw.Draw(thumbs).text((x+10,y+365),'S%02d %s  %.2fs'%(sh['shot'],sh['name'],(f-1)/30),font=font,fill=(171,191,205))
thumbs.save(R/'delivery/contact_sheet.jpg',quality=94)
print(json.dumps({k:v for k,v in proof.items() if k!='seams'},indent=2))
