"""Compose only frames 301 onward; original 300 frames are never processed."""
from pathlib import Path
from PIL import Image,ImageEnhance
import json,os,bisect
R=Path(__file__).resolve().parents[1];P=json.loads((R/'analysis/plan.json').read_text());SH=P['shots'];out=R/'edited_frames';out.mkdir(exist_ok=True)
# Dissolves are confined to changes of biological scale / symbolic convergence.
# All transitions have real rendered handles on both sides.
transitions={2:6,3:6,9:9,17:9}
def source(idx,f):return R/'frames'/('S%02d'%idx)/('frame_%04d.png'%f)
def image(idx,f):
 p=source(idx,f)
 with Image.open(p) as im:
  assert im.size==(1920,1080),(p,im.size)
  return im.convert('RGB')
compose_end=min(P['frames'],int(os.environ.get('COL_COMPOSE_END',str(P['frames']))))
for f in range(301,compose_end+1):
 idx=next(sh['shot'] for sh in SH if sh['first_frame']<=f<=sh['last_frame'])
 dst=out/('frame_%04d.png'%f)
 if dst.exists():continue
 blended=None
 for before,width in transitions.items():
  boundary=SH[before-1]['last_frame'];a=boundary-width+1;b=boundary+width
  if a<=f<=b:
   t=(f-a)/(b-a);t=t*t*(3-2*t)
   blended=Image.blend(image(before,f),image(before+1,f),t);break
 if f>=1620:
  im=blended if blended is not None else image(idx,f)
  t=max(0,min(1,(f-1620)/30));factor=1-t*t*(3-2*t)
  im=Image.new('RGB',(1920,1080),(0,0,0)) if f>=1650 else ImageEnhance.Brightness(im).enhance(factor)
  im.save(dst,compress_level=2)
 elif blended is not None:blended.save(dst,compress_level=2)
 else:os.link(source(idx,f),dst)
 if f%100==0:print('COMPOSED',f,flush=True)
print('COMPOSITION_COMPLETE',flush=True)
