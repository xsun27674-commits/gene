import csv,json,subprocess
from pathlib import Path
import numpy as np
from scipy.io import wavfile
from scipy.signal import stft,find_peaks,correlate
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=Path(__file__).resolve().parents[1]
sr,x=wavfile.read(R/'audio/analysis.wav');x=x.astype(float)/32768
f,t,z=stft(x,sr,nperseg=1024,noverlap=768)
flux=np.r_[0,np.maximum(np.diff(np.log1p(abs(z)*100),axis=1),0).mean(axis=0)]
flux=np.convolve(flux,np.ones(3)/3,'same');dt=t[1]-t[0]
peaks,_=find_peaks(flux,distance=int(.22/dt),prominence=np.percentile(flux,65)*.65)
ac=correlate(flux-flux.mean(),flux-flux.mean(),mode='full')[len(flux)-1:]
lo,hi=int(60/180/dt),int(60/70/dt);bpm=60/((np.argmax(ac[lo:hi])+lo)*dt)
probe=json.loads(subprocess.check_output(['ffprobe','-v','error','-select_streams','a:0','-show_entries','stream=duration','-of','json',str(R/'audio/SOURCE_MUSIC.m4a')],text=True))
duration=float(probe['streams'][0]['duration']);frames=round(duration*30)
threshold=np.percentile(flux[peaks],75)
with (R/'delivery/beat_map.csv').open('w',newline='') as fp:
 w=csv.writer(fp);w.writerow(['seconds','frame_zero_based','strength','classification','suggested_action'])
 for p in peaks:
  strong=flux[p]>=threshold
  w.writerow([round(t[p],5),round(t[p]*30),round(float(flux[p]),7),'accent_candidate' if strong else 'transient','major reveal / matched cut' if strong else 'focus / subtle light only'])
targets=[0,10,11.5,13.5,16.5,19,22.5,25,27.5,30.5,32.8,35,37,39,41.5,44,46,49,52,duration]
names=['ORIGINAL_DNA','DNA_CONTINUATION','CHROMATIN','REPLICATED_CHROMOSOME','HOMOLOGUE_PAIRING','CROSSING_OVER','RECOMBINANTS','MEIOSIS_I','MEIOSIS_II','FLOWERS','MAIZE','BUTTERFLY','IRIS','CAT','LEAF','FOREST','LIFE_MONTAGE','CONVERGENCE','DNA_FINALE']
bounds=[0,300]
for target in targets[2:-1]:
 candidates=[p for p in peaks if abs(t[p]-target)<.35]
 if candidates:
  p=max(candidates,key=lambda p:float(flux[p]/max(flux[peaks]))*.22-abs(t[p]-target))
  frame=round(t[p]*30)
 else:frame=round(target*30)
 bounds.append(max(bounds[-1]+18,frame))
bounds.append(frames)
shots=[]
for i,name in enumerate(names):
 shots.append({'shot':i+1,'name':name,'start':bounds[i]/30,'end':bounds[i+1]/30,'first_frame':bounds[i]+1,'last_frame':bounds[i+1],'frames':bounds[i+1]-bounds[i],'handles_frames':9,'type':'preserved_bitstream' if i==0 else '3d' if i<9 or i>=17 else 'macro_texture'})
with (R/'delivery/shot_list.csv').open('w',newline='') as fp:
 w=csv.DictWriter(fp,fieldnames=list(shots[0]));w.writeheader();w.writerows(shots)
out={'source_duration':duration,'video_duration':frames/30,'frames':frames,'fps':30,'bpm_candidate':round(float(bpm),3),'tempo_note':'Autocorrelation estimate, possible metrical ambiguity; accents are spectral candidates cross-checked against waveform, not every transient is a downbeat.','shots':shots}
(R/'analysis/plan.json').write_text(json.dumps(out,indent=2))
fig,axs=plt.subplots(2,1,figsize=(18,6),sharex=True,facecolor='#050a12')
for a in axs:a.set_facecolor('#050a12');a.tick_params(colors='white')
axs[0].plot(np.arange(len(x))[::200]/sr,x[::200],lw=.35,color='#70badb')
axs[1].plot(t,flux,lw=.7,color='#cda456');axs[1].scatter(t[peaks],flux[peaks],s=5,color='#a9d8f0')
for sh in shots:
 for a in axs:a.axvline(sh['start'],color='#a9bdd0',alpha=.35,lw=.6)
 axs[0].text(sh['start']+.04,.75,'S%02d'%sh['shot'],fontsize=7,color='white')
fig.tight_layout();fig.savefig(R/'analysis/music_and_shots.png',dpi=130)
print(json.dumps(out,indent=2))
