"""ISO BMFF audio edit list preserves intro AAC samples and skips encoder pads.
Input must be an ordinary non-fragmented MP4 with moov AFTER mdat, created with
movie_timescale=48000. Move the rebuilt moov to the front and update chunk offsets.
"""
from pathlib import Path
import struct,json,sys
def atoms(data):
 pos=0
 while pos<len(data):
  size,typ=struct.unpack_from('>I4s',data,pos);head=8
  if size==1:size=struct.unpack_from('>Q',data,pos+8)[0];head=16
  if size==0:size=len(data)-pos
  assert size>=head and pos+size<=len(data),(typ,pos,size,len(data))
  yield typ,data[pos+head:pos+size],pos,size
  pos+=size
def box(typ,data):return struct.pack('>I4s',len(data)+8,typ)+data
def handler(track):
 for typ,p,_,_ in atoms(track):
  if typ==b'mdia':
   for t,v,_,_ in atoms(p):
    if t==b'hdlr':return v[8:12]
def patch_audio_track(track,total_movie_ticks,old_packets,remainder_samples):
 # First edit is exactly the existing 480000 audible samples. The second edit
 # skips the intro's encoder padding AND the new encoder's 1024-sample priming.
 # Retain the first segment through its AAC frame boundary. Any encoded tail
 # (256 samples for this source) replaces the same tiny interval of the new
 # master, so later music stays at its absolute source time with no overlap.
 first_duration=old_packets*1024-1024
 tail=first_duration-480000
 # The new encoder is fed one real AAC frame of preroll before the handoff.
 # Both edit starts are therefore AAC-frame aligned on all MP4 players.
 second_time=old_packets*1024+2048
 entries=[(first_duration,1024),(remainder_samples-tail,second_time)]
 elst=box(b'elst',b'\x00\x00\x00\x00'+struct.pack('>I',2)+b''.join(struct.pack('>Iihh',duration,time,1,0) for duration,time in entries))
 edts=box(b'edts',elst);result=[];found=False
 for typ,p,_,_ in atoms(track):
  if typ==b'edts':result.append(edts);found=True
  elif typ==b'tkhd':
   d=bytearray(p);assert d[0]==0;struct.pack_into('>I',d,20,480000+remainder_samples);result.append(box(typ,d))
  else:result.append(box(typ,p))
 if not found:result.insert(1,edts)
 return b''.join(result)
def shift_chunks(data,delta):
 containers={b'moov',b'trak',b'mdia',b'minf',b'stbl',b'edts'};out=[]
 for typ,p,_,_ in atoms(data):
  if typ in containers:p=shift_chunks(p,delta)
  elif typ in [b'stco',b'co64']:
   d=bytearray(p);count=struct.unpack_from('>I',d,4)[0];fmt='>I' if typ==b'stco' else '>Q';step=4 if typ==b'stco' else 8
   for i in range(count):
    pos=8+i*step;v=struct.unpack_from(fmt,d,pos)[0];struct.pack_into(fmt,d,pos,v+delta)
   p=d
  out.append(box(typ,p))
 return b''.join(out)
def rebuild(src,dst,old_packets,remainder_samples,video_frames):
 data=Path(src).read_bytes();top=list(atoms(data));moov=next(x for x in top if x[0]==b'moov');mdat=next(x for x in top if x[0]==b'mdat');assert moov[2]>mdat[2]
 movie_ticks=video_frames*1600;parts=[];audio_tracks=0
 for typ,p,_,_ in atoms(moov[1]):
  if typ==b'mvhd':
   d=bytearray(p);assert d[0]==0;assert struct.unpack_from('>I',d,12)[0]==48000;struct.pack_into('>I',d,16,movie_ticks);p=d
  elif typ==b'trak' and handler(p)==b'soun':p=patch_audio_track(p,movie_ticks,old_packets,remainder_samples);audio_tracks+=1
  parts.append(box(typ,p))
 assert audio_tracks==1
 newmoov=box(b'moov',b''.join(parts));newmoov=shift_chunks(newmoov,len(newmoov))
 ftyp=next(x for x in top if x[0]==b'ftyp');assert ftyp[2]==0
 rest=b''.join(data[pos:pos+size] for typ,p,pos,size in top if typ not in [b'ftyp',b'moov'])
 Path(dst).write_bytes(data[:ftyp[3]]+newmoov+rest)
 return {'old_aac_packets':old_packets,'intro_audible_samples':480000,'encoded_intro_tail_samples':old_packets*1024-1024-480000,'new_master_source_in':(old_packets*1024-2048)/48000,'second_edit_media_sample':old_packets*1024+2048,'remainder_samples':remainder_samples,'video_frames':video_frames,'movie_timescale':48000,'faststart':True}
if __name__=='__main__':
 print(json.dumps(rebuild(sys.argv[1],sys.argv[2],int(sys.argv[3]),int(sys.argv[4]),int(sys.argv[5])),indent=2))
