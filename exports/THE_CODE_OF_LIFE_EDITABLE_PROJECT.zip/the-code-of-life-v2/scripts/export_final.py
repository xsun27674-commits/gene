"""Stream-copy protected intro video; preserve its AAC through edit lists."""
from pathlib import Path
import subprocess,json,sys
from PIL import Image
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'scripts'))
from assemble_audio_edits import rebuild
P=json.loads((R/'analysis/plan.json').read_text())
(R/'segments').mkdir(parents=True,exist_ok=True)
(R/'delivery').mkdir(parents=True,exist_ok=True)
def run(args):subprocess.run(args,check=True)
for f in range(301,P['frames']+1):
 p=R/'edited_frames'/('frame_%04d.png'%f)
 with Image.open(p) as im:im.verify()
 with Image.open(p) as im:assert im.size==(1920,1080)
new=R/'segments/NEW_AFTER_10.mp4';full=R/'segments/FULL_VIDEO_ONLY.mp4';raw=R/'segments/BEFORE_EDIT_LIST.mp4'
run(['ffmpeg','-hide_banner','-y','-framerate','30','-start_number','301','-i',str(R/'edited_frames/frame_%04d.png'),'-frames:v',str(P['frames']-300),'-an','-vf','setsar=1','-c:v','libx264','-preset','slow','-crf','16','-pix_fmt','yuv420p','-video_track_timescale','15360',str(new)])
lst=R/'segments/concat_video.txt';lst.write_text("file '../assets/ORIGINAL_10s.mp4'\nduration 10.000000\nfile 'NEW_AFTER_10.mp4'\n")
run(['ffmpeg','-hide_banner','-y','-copyts','-f','concat','-safe','0','-i',str(lst),'-map','0:v:0','-an','-c:v','copy','-avoid_negative_ts','disabled','-video_track_timescale','15360',str(full)])
if not (R/'audio/combined_encoded.aac').exists():run([sys.executable,str(R/'scripts/prepare_audio.py')])
run(['ffmpeg','-hide_banner','-y','-i',str(full),'-i',str(R/'audio/combined_encoded.aac'),'-map','0:v:0','-map','1:a:0','-c','copy','-movie_timescale','48000','-video_track_timescale','15360','-avoid_negative_ts','disabled',str(raw)])
meta=rebuild(raw,R/'delivery/THE_CODE_OF_LIFE_FINAL.mp4',470,round(P['source_duration']*48000)-480000,P['frames'])
(R/'analysis/audio_edit_metadata.json').write_text(json.dumps(meta,indent=2))
# Separate scene videos (with handles) are retained for later editing.
for sh in P['shots'][1:]:
 dst=R/'segments'/('S%02d_%s.mp4'%(sh['shot'],sh['name']))
 if dst.exists():continue
 first=max(301,sh['first_frame']-9);last=min(P['frames'],sh['last_frame']+9)
 run(['ffmpeg','-hide_banner','-loglevel','error','-y','-framerate','30','-start_number',str(first),'-i',str(R/'frames'/('S%02d'%sh['shot'])/'frame_%04d.png'),'-frames:v',str(last-first+1),'-an','-c:v','libx264','-preset','veryfast','-crf','18','-pix_fmt','yuv420p','-vf','setsar=1',str(dst)])
print('FINAL_EXPORT_COMPLETE',flush=True)
