# THE CODE OF LIFE｜生命的密码 · V2

整片以用户提供的音乐为准，计划输出 55.333 秒、1920×1080、30 FPS、1660 帧。
实际完成情况以 `delivery/validation.json` 与 `delivery/render_report.txt` 为准。
无旁白、无字幕、无片名、无水印。

## 观看与编辑

下载已导出的 `THE_CODE_OF_LIFE_FINAL.mp4` 即可在 Windows 播放，无需运行代码。
工程 ZIP 是源资产与可恢复的制作脚本，先完整解压再打开 `.blend` 文件，避免单独移动文件造成纹理丢失。

- `assets/ORIGINAL_10s.mp4`：受保护的原版 10 秒成片。
- `assets/ORIGINAL_10s.blend`：原片的相机、几何和材质来源。
- `scenes/S02_*.blend`：从第 301 帧继承相机位置、朝向、焦距和初速度的后续镜头。
- `scenes/S03_*.blend`：DNA 绕组蛋白八聚体形成核小体，含双链连接 DNA。
- `scenes/S04_*.blend` 至 `S09_*.blend`：减数分裂与交叉互换；各场景使用共同的全局时间轴，便于逐帧检查。
- `scenes/S18_*.blend`、`S19_*.blend`：生物纹理汇聚、DNA 结尾。
- `assets/*.png`：宏观原始生成图像与透明鸟前景。
- `audio/SOURCE_MUSIC.m4a`：从用户附件无损抽出的音轨，不包含附件自带的视频画面。
- `delivery/beat_map.csv`、`shot_list.csv`：音乐瞬态、强度与帧级剪辑表。
- `scripts/`：完整场景构建、虚拟摄影、渲染、封装与验证脚本。

本工程保留原版 0–10 秒视频码流，不经过图像处理或重新渲染。
最终验证会比较原片与成片的前 300 个解码帧，以及前 480000 个双声道 PCM 样本。
音轨使用 AAC 帧对齐的编辑列表衔接；新增段在 9.984 秒取编码预卷，最终展示仍从原片之后继续，
不重复叠加音乐、不变速。原片末尾 256 个 AAC 编码补偿样本只占第 10 秒之后约 5.33 ms；
随后接续到同一音乐时刻。新增音乐段进行约 -1.11 dB 峰值余量处理，结尾 0.6 秒淡出。

## 影像来源与限制

微观部分为 Blender Eevee CGI，并非真实显微摄影。
宏观部分使用本次生成的摄影质感图像，进行推拉、微距滑轨和纹理匹配剪辑。
鸟类镜头采用生成的透明前景与森林背景做 2.5D 滑翔合成；不是实拍，也不是连续 AI 动物视频。
这些是缺少视频生成工具时，按文档允许的微距／纹理方案制作的镜头。
部分生成图像宽约 1672 像素，虚拟摄影会有裁切与上采样；不能等同于原生 4K 摄影素材。
GPU 不可用时采用 CPU 软件渲染，采样和高速景深仍有精修空间。

## 科学范围

本片采用单对同源染色体的 `2n=2` 简化模型，不代表人类完整染色体组。
核小体示意为组蛋白八聚体与约 1.65 圈左手 DNA 缠绕，每个核心显示 147 个示意碱基对。
不宣称所有染色质都有统一的 30 nm 纤维形态。
四条染色单体中，只有 M2 和 P1 两条非姐妹染色单体交换对应远端片段；M1、P2 保持亲本状态。
第一次分裂分离同源染色体，第二次分裂分离姐妹染色单体，形成四个单倍体产物。
不默认四个产物都是功能性配子。花色、玉米、虹膜、猫毛等是独立表型例子，
不暗示所有差异都由同一次交叉互换产生。生物影像汇向 DNA 是艺术隐喻，不是物种互变。
全部分子几何是层级结构示意，不是实验原子坐标模型。

## 可恢复制作

每个云任务已经隔离，直接使用现有目录，不需要创建 Git worktree。
需要 Blender 4.3.2、FFmpeg 7.1，以及 `requirements.txt` 中的 Python 库。
下面是给技术人员或后续 Codex 任务使用的命令，观看成片不需要执行。

```sh
python scripts/prepare_audio.py
python scripts/analyze_plan.py
blender -b assets/ORIGINAL_10s.blend -t 5 --python scripts/build_continuation.py
blender -b -t 5 --python scripts/build_micro.py -- chromatin
blender -b -t 5 --python scripts/build_micro.py -- science
blender -b assets/ORIGINAL_10s.blend -t 5 --python scripts/build_finale.py
python scripts/run_previews.py
python scripts/run_native.py
python scripts/render_macro.py
python scripts/compose_frames.py
python scripts/export_final.py
python scripts/validate_final.py
python scripts/package_project.py
```

`run_native.py` 按镜头输出 PNG，并在同一连续 3D 场景之间复用一致的过渡余量。
`render_shot.py` 从未完成位置续跑，且不会渲染任何第 300 帧及之前的原片画面。
修改相机或资产后，应先移动受影响镜头的旧帧缓存，再重新生成。
`frames/`、`edited_frames/`、`segments/` 是可重建的较大缓存，在制作云环境中保留，工程 ZIP 不包含所有缓存。
每段正式渲染另有独立静音 MP4；最终成片只使用一条音乐主轨。
结尾合成包含短黑场，用于用户后期接片名；本片本身没有任何文字。

`assemble_audio_edits.py` 只用于当前非分片 MP4，要求输入 moov 位于 mdat 后、movie timescale=48000。
脚本会重建音轨编辑列表并更新全部 chunk offset，将 moov 移到前部用于流式下载。
请不要把它用于任意未知结构的 MP4。

制作与复现脚本不会自动提交或推送 GitHub。正式交付使用本会话用户已经同意的 `gene/main` 仓库通道，
新版采用新文件名，原版 `THE_CODE_OF_LIFE_10s.mp4` 保留。
